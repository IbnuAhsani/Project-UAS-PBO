package googletranslate;

import java.util.ArrayList;
import java.util.List;

public class Config
{
  public List<String> languages = new ArrayList();
  public String font;
}


/* Location:              /home/jas/sites/icu-transliteration-application/Translit_Application.jar!/googletranslate/Config.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */