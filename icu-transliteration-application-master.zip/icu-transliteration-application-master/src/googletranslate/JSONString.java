package googletranslate;

public abstract interface JSONString
{
  public abstract String toJSONString();
}


/* Location:              /home/jas/sites/icu-transliteration-application/Translit_Application.jar!/googletranslate/JSONString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */